University Marketing Web Logos

Use
------------
These logos are to be used for web purposes only.

  SVG 
      RGB, XML-based vector image format
      All modern browsers have native SVG support

  PNG 
      RGB, raster graphics file format that supports lossless data compression
      All modern browsers have native PNG support

  PDF 
      RGB, vector-based files
      General-purpose format that requires a specialized program like Adobe Photoshop or Adobe Illustrator to create a web-ready format


Contact
-------------
University Marketing, UW–Madison
brand@umark.wisc.edu
608-262-0948